# Handle table-like data and matrices
import numpy as np
import pandas as pd

# Modelling Algorithms
from sklearn.linear_model import LogisticRegression, LassoLarsCV,Ridge
from sklearn.ensemble import  RandomForestRegressor

# Modelling Helpers
from sklearn.preprocessing import Imputer , Normalizer , scale, OneHotEncoder
from sklearn.model_selection import train_test_split, StratifiedKFold
from sklearn.feature_selection import RFECV
from sklearn.preprocessing import LabelEncoder,OneHotEncoder

# Visualisation
import matplotlib.pyplot as plt
import seaborn as sns

#loading data from local rep
traindf = pd.read_csv("../data/train.csv")
testdf = pd.read_csv("../data/test.csv")

# create a single dataframe of both the training and testing data
df = pd.concat([traindf , testdf], sort=False)

df.drop(['MiscFeature','PoolQC','Fence','FireplaceQu','Alley','LotFrontage'],axis=1,inplace=True)


#seting our target
traincorr = traindf.corr()['SalePrice']
# convert series to dataframe so it can be sorted
traincorr = pd.DataFrame(traincorr)
# correct column label from SalePrice to correlation
traincorr.columns = ["Correlation"]
# sort correlation - to see on what to start with
traincorr2 = traincorr.sort_values(by=['Correlation'], ascending=False)

corr = df.corr()

#Inspecting data - Missing Values
countmissing = df.isnull().sum().sort_values(ascending=False)
percentmissing = (df.isnull().sum()/df.isnull().count()).sort_values(ascending=False)
wholena = pd.concat([countmissing,percentmissing], axis=1)


#Replace Missing values
df[["Utilities", "Id"]].groupby(['Utilities'], as_index=False).count()
df['Utilities'] = df['Utilities'].fillna("AllPub")

# df[["Electrical", "Id"]].groupby(['Electrical'], as_index=False).count()
df['Electrical'] = df['Electrical'].fillna("SBrkr")

# df[["Exterior1st", "Id"]].groupby(['Exterior1st'], as_index=False).count()
df['Exterior1st'] = df['Exterior1st'].fillna("VinylSd")

#df[["Exterior2nd", "Id"]].groupby(['Exterior2nd'], as_index=False).count()
df['Exterior2nd'] = df['Exterior2nd'].fillna("VinylSd")


# Missing interger values replace with the median in order to return an integer
df['BsmtFullBath'] = df.BsmtFullBath.fillna(df.BsmtFullBath.median())
df['BsmtHalfBath'] = df.BsmtHalfBath.fillna(df.BsmtHalfBath.median())
df['GarageCars'] = df.GarageCars.fillna(df.GarageCars.median())

# Missing float values were replaced with the mean for accuracy
df['BsmtUnfSF'] = df.BsmtUnfSF.fillna(df.BsmtUnfSF.mean())
df['BsmtFinSF2'] = df.BsmtFinSF2.fillna(df.BsmtFinSF2.mean())
df['BsmtFinSF1'] = df.BsmtFinSF1.fillna(df.BsmtFinSF1.mean())
df['GarageArea'] = df.GarageArea.fillna(df.GarageArea.mean())
df['MasVnrArea'] = df.MasVnrArea.fillna(df.MasVnrArea.mean())
# fill missing year
df.GarageYrBlt.fillna(df.YearBuilt, inplace=True)
df.TotalBsmtSF.fillna(df['1stFlrSF'], inplace=True)

# Lot Frontage : there are 486 missing values

lot = df[['LotArea','LotConfig','LotShape']]
lot = pd.get_dummies(lot)
# Where are we right now

lot["LotAreaUnSq"] = np.sqrt(lot['LotArea'])


#--------- Add variables section -------

Livingtotalsq = df['TotalBsmtSF'] + df['1stFlrSF'] + df['2ndFlrSF'] + df['GarageArea'] + df['WoodDeckSF'] + df['OpenPorchSF']
df['LivingTotalSF'] = Livingtotalsq

# Total Living Area divided by LotArea
df['PercentSQtoLot'] = df['LivingTotalSF'] / df['LotArea']

# Total count of all bathrooms including full and half through the entire building
df['TotalBaths'] = df['BsmtFullBath'] + df['BsmtHalfBath'] + df['HalfBath'] + df['FullBath']

# Percentage of total rooms are bedrooms
df['PercentBedrmtoRooms'] = df['BedroomAbvGr'] / df['TotRmsAbvGrd']

# Number of years since last remodel, if there never was one it would be since it was built
df['YearSinceRemodel'] = 2016 - ((df['YearRemodAdd'] - df['YearBuilt']) + df['YearBuilt'])


#Feature engineering
pricing1 = df[['Id','SalePrice','MiscVal']]

neigh = df[['Neighborhood','MSZoning','MSSubClass','BldgType','HouseStyle']]

dates = df[['YearBuilt','YearRemodAdd','GarageYrBlt','YearSinceRemodel']]

quacon = df[['ExterQual','BsmtQual','Condition1','Condition2','SaleCondition',
                  'BsmtCond','ExterCond','GarageCond','KitchenQual','GarageQual','HeatingQC','OverallQual','OverallCond']]

features =  df[['Foundation','RoofStyle','RoofMatl','Exterior1st','Exterior2nd',
                     'PavedDrive','Utilities',
                     'Heating','CentralAir','Electrical']]

sqfoot = df[['LivingTotalSF','TotalBsmtSF','1stFlrSF','2ndFlrSF','GrLivArea',
                  'GarageArea','WoodDeckSF','OpenPorchSF','LotArea','PercentSQtoLot','LowQualFinSF']]

roomfeatcount = df[['PercentBedrmtoRooms','TotalBaths','FullBath','HalfBath',
                         'KitchenAbvGr','TotRmsAbvGrd','Fireplaces','GarageCars','GarageType','EnclosedPorch']]

# Splits out sale price for the training set and only has not null values
pricing = df['SalePrice']
pricing = pricing[pricing.notnull()]

# Bringing it all together
df = pd.concat([pricing1,neigh,dates,quacon,features,sqfoot,roomfeatcount], axis=1)



#Looking to the new correlation with data

df = pd.get_dummies(df)
traincorr = df.corr()['SalePrice']
# convert series to dataframe so it can be sorted
traincorr = pd.DataFrame(traincorr)
# correct column label from SalePrice to correlation
traincorr.columns = ["Correlation"]
# sort correlation
traincorr2 = traincorr.sort_values(by=['Correlation'], ascending=False)
print(' New correlation aftre adjustment of data df')


#We are suppose to delet price, but not before wrting the df to csv
train_X = df[df['SalePrice'].notnull()]

test_X = df[df['SalePrice'].isnull()]
del test_X['SalePrice']


#Now we do del SalePrice from train
del train_X['SalePrice']

# Create all datasets that are necessary to train, validate and test models
train_valid_X = train_X
z_data = train_valid_X

#target
train_valid_y = pricing
#no change needed to the test set
test_X = test_X

train_X , valid_X , train_y , valid_y = train_test_split( train_valid_X , train_valid_y , train_size = .7 )


# loading model to use

model = RandomForestRegressor()
# model = SVC()

model.fit( train_X , train_y )

# Print the Training Set Accuracy and the Test Set Accuracy in order to understand overfitting
print(model.score( train_X , train_y ))
print(model.score( valid_X , valid_y ))
print(model.score( train_valid_X , train_valid_y ))

#output
id = test_X.Id
result = model.predict(test_X)



model = LogisticRegression()

model.fit( train_X , train_y )

# Print the Training Set Accuracy and the Test Set Accuracy in order to understand overfitting
print (model.score( train_X , train_y ))
print(model.score( valid_X , valid_y ))

#output
id = test_X.Id
result = model.predict(test_X)





from sklearn.model_selection import cross_val_predict, GridSearchCV, cross_val_score
from sklearn.ensemble import RandomForestRegressor

print("New section just added for test: ")

rfr = RandomForestRegressor(max_depth=100, n_estimators=1000,
                                criterion='mae',random_state=False, verbose=False)
rfr.fit(train_X , train_y )
print(rfr.score( train_X , train_y ))
print(rfr.score( valid_X , valid_y  ))
print(rfr.score( train_valid_X ,train_valid_y ))

test_y_prediction = rfr.predict(test_X)



id2 = test_X.Id
result2 = rfr.predict(test_X)


# output
feature_importances_model = pd.DataFrame(model.feature_importances_,index = train_X.columns,
columns=['importance']).sort_values('importance', ascending=False)
feature_importances_rfr = pd.DataFrame(rfr.feature_importances_,index = train_X.columns,
                                   columns=['importance']).sort_values('importance', ascending=False)